package attraction;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import attraction.AttractionDaoImpl;
import user.UserDto;
import user.UserMain;
import user.UserService;
import user.UserServiceImpl;

public class AttractionMain {

     BufferedReader in;
        AttractionDao bs = AttractionDaoImpl.getAttraction();

        public AttractionMain() {
            in = new BufferedReader(new InputStreamReader(System.in));
            menu();
        }

        private void menu() {
            while (true) {
                System.out.println("---------- 게시판 메뉴 ----------");
                System.out.println("1. 관심 지역 등록");
                System.out.println("2. 관심 지역 확인");
                System.out.println("-------------------------------------");
                System.out.println("0. 프로그램 종료");
                System.out.println("-------------------------------------");
                System.out.print("메뉴 선택 : ");
                try {
                    int num = Integer.parseInt(in.readLine());
                    switch (num) {
                    case 1:
                        registerArea();
                        break;
                    case 2:
                        System.out.println("회원이름을 입력하세요");
                        String id2 = in.readLine();
                        getArea(id2);
                        break;
                  
                    default:
                        System.exit(0);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void registerArea() throws IOException {
            System.out.println("=== 관심 지역 추가하기 ===");
            System.out.print("회원 이름 : ");
            String user_name = in.readLine();
            System.out.print("동 이름 : ");
            String dong_name = in.readLine();
            
            
            bs.registerArea(dong_name, user_name);
        }

        private void getArea(String user_name) {
            String area = bs.getAttractiveArea(user_name);
            System.out.println("********** 관심지역 **********");
            System.out.println(area.toString());
        }
        
        public static void main(String[] args) {
            new AttractionMain();
        }
}