package attraction;

public class AttractionDto {
    private String dong_name;
    private String user_name;
    
    public AttractionDto() {
    
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getDong_name() {
        return dong_name;
    }
    public void setDong_name(String dong_name) {
        this.dong_name = dong_name;
    }

    @Override
    public String toString() {
        return "AttractionDto{" +
                "dong_name='" + dong_name + '\'' +
                ", user_name='" + user_name + '\'' +
                '}';
    }
}