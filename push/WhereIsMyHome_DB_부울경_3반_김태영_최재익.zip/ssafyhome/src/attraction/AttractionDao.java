package attraction;

public interface AttractionDao {
    void registerArea(String dong_name, String user_name);
    void deleteArea(int dong_id);
    String getAttractiveArea(String id);
}