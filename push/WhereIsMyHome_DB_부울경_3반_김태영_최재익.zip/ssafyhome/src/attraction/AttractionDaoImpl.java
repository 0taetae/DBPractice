package attraction;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DBUtil;

public class AttractionDaoImpl implements AttractionDao{
    
    private final String driverName = "com.mysql.cj.jdbc.Driver";
    private final String url = "jdbc:mysql://70.12.60.80:3306/ssafyhome?serverTimezone=UTC";
    private final String user = "ssafy";
    private final String pass = "ssafy";
    
    private static AttractionDao attractionDao;
    
    private AttractionDaoImpl() {}
    
    public static AttractionDao getAttraction() {
        if(attractionDao==null) {
            return new AttractionDaoImpl();
        }
        return attractionDao;
    }


    @Override
    public void registerArea(String dong_name, String user_name) {
        Connection conn = null;
        PreparedStatement selectDongStatement = null;
        PreparedStatement selectUserStatement = null;
        PreparedStatement insertStatement = null;
        ResultSet rsDong = null;
        ResultSet rsUser = null;

        try {
            // Step 1: Establish a connection to the database
            conn = DBUtil.getInstance().getConnection();

            // Step 2: Prepare the SELECT statement to check if dong_name exists in dong_codes
            String selectDongQuery = "SELECT * FROM dongcodes WHERE dong_name = ?";
            selectDongStatement = conn.prepareStatement(selectDongQuery);
            selectDongStatement.setString(1, dong_name);

            // Step 3: Execute the query and get the result
            rsDong = selectDongStatement.executeQuery();

            if (rsDong.next()) {
                // Step 4: Prepare the SELECT statement to check if user_name exists in user table
                String selectUserQuery = "SELECT * FROM user WHERE name = ?";
                selectUserStatement = conn.prepareStatement(selectUserQuery);
                selectUserStatement.setString(1, user_name);

                // Step 5: Execute the query and get the result
                rsUser = selectUserStatement.executeQuery();

                if (rsUser.next()) {
                    // Step 6: Prepare the INSERT statement to save into the attraction table
                    String insertQuery = "INSERT INTO attraction (dong_name, user_name) VALUES (?, ?)";
                    insertStatement = conn.prepareStatement(insertQuery);
                    insertStatement.setString(1, rsDong.getString("dong_name")); // dong_name from dong_codes
                    insertStatement.setString(2, rsUser.getString("name")); // user_name from user table

                    // Step 7: Execute the insert statement
                    insertStatement.executeUpdate();
                    System.out.println("Data successfully inserted into the attraction table.");
                } else {
                    System.out.println("No matching user_name found in user table.");
                }
            } else {
                System.out.println("No matching dong_name found in dong_codes.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Step 8: Clean up the resources
            try {
                if (rsDong != null) rsDong.close();
                if (rsUser != null) rsUser.close();
                if (selectDongStatement != null) selectDongStatement.close();
                if (selectUserStatement != null) selectUserStatement.close();
                if (insertStatement != null) insertStatement.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
//    @Override
//    public void registerArea(String dong_name, String user_name) {
//        Connection conn = null;
//        PreparedStatement selectStatement = null;
//        PreparedStatement insertStatement = null;
//        ResultSet rs = null;
//
//        try {
//            // Step 1: Establish a connection to the database
//            conn = DBUtil.getInstance().getConnection();
//
//            // Step 2: Prepare the SELECT statement to check if dong_name exists in dong_codes
//            String selectQuery = "SELECT * FROM dong_codes WHERE dong_name = ?";
//            selectStatement = conn.prepareStatement(selectQuery);
//            selectStatement.setString(1, dong_name);
//
//            // Step 3: Execute the query and get the result
//            rs = selectStatement.executeQuery();
//
//            if (rs.next()) {
//                // Step 4: Prepare the INSERT statement to save into the attraction table
//                String insertQuery = "INSERT INTO attraction (dong_name, user_name) VALUES (?, ?)";
//                insertStatement = conn.prepareStatement(insertQuery);
//                insertStatement.setString(1, rs.getString("dong_name"));
//                insertStatement.setString(2, rs.getString("user_name"));
//
//                // Step 5: Execute the insert statement
//                insertStatement.executeUpdate();
//                System.out.println("Data successfully inserted into the attraction table.");
//            } else {
//                System.out.println("No matching dong_name found in dong_codes.");
//            }
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        } finally {
//            // Step 6: Clean up the resources
//            try {
//                if (rs != null) rs.close();
//                if (selectStatement != null) selectStatement.close();
//                if (insertStatement != null) insertStatement.close();
//                if (conn != null) conn.close();
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }
//    }

    @Override
    public void deleteArea(int dong_id) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public String getAttractiveArea(String userName) {
        String dongName = null;
        String sql = "SELECT dong_name FROM attraction WHERE user_name = ?";

        // DB 연결을 가져옵니다.
        try (Connection conn = DBUtil.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // SQL 쿼리의 첫 번째 파라미터에 입력 받은 userName을 설정합니다.
            pstmt.setString(1, userName);

            // 쿼리를 실행하고 결과를 얻습니다.
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    // dong_name 값을 가져옵니다.
                    dongName = rs.getString("dong_name");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // 오류 로그 출력
        }

        return dongName; // 조회된 dong_name을 반환
    }

//    @Override
//    public AttractionDto getAttractiveArea(String id) {
//        AttractionDto attractionDto = null;
//        try (Connection conn = DBUtil.getInstance().getConnection();){
//            StringBuilder sql = new StringBuilder();
//            sql.append("select dong_name, user_user_id");
//            sql.append("from attraction ");
//            sql.append("where article_no ="+id+" ");
//            try(PreparedStatement pstmt = conn.prepareStatement(sql.toString()); ResultSet rs = pstmt.executeQuery();){
//                if(rs.next()) {
//                    attractionDto = new AttractionDto();
//                    attractionDto.setDong_name(rs.getString("dong_name"));
//                    attractionDto.set_id(rs.getString("dong_name"));
//                }
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return attractionDto;
//    }
}