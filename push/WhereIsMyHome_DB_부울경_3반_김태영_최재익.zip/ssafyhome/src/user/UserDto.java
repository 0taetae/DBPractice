package user;

public class UserDto {
	private int user_id;
	private String name;
	private String id;
	private String pw;
	private String address;
	private String phoneNumber;
	
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	@Override
	public String toString() {
	    return "User Information:" +
	           "\n- User ID: " + user_id +
	           "\n- Name: " + name +
	           "\n- Username: " + id +
	           "\n- Password: [Protected]" +  // 비밀번호는 보호된 정보로 출력하지 않는 것이 좋음
	           "\n- Address: " + address +
	           "\n- Phone Number: " + phoneNumber;
	}

	
	
}
