package user;

public interface UserDao {
	void registerUser(UserDto userDto);
	UserDto getProfile(String id);
	void deleteUser(String id);
}
