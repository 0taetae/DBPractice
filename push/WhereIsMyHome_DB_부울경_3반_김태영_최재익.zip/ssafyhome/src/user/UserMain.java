package user;

import java.io.*;
import java.util.List;
import user.*;

public class UserMain {

    BufferedReader in;
    UserService bs = UserServiceImpl.getUserService();

    public UserMain() {
        in = new BufferedReader(new InputStreamReader(System.in));
        menu();
    }

    private void menu() {
        while (true) {
            System.out.println("---------- 게시판 메뉴 ----------");
            System.out.println("1. 회원 정보 등록");
            System.out.println("2. 회원 정보 확인");
            System.out.println("3. 회원 정보 삭제");
            System.out.println("-------------------------------------");
            System.out.println("0. 프로그램 종료");
            System.out.println("-------------------------------------");
            System.out.print("메뉴 선택 : ");
            try {
                int num = Integer.parseInt(in.readLine());
                switch (num) {
                case 1:
                    registerUser();
                    break;
                case 2:
                	System.out.println("회원 번호를 입력하세요");
                	String id1 = in.readLine();
                    getProfile(id1);
                    break;
                case 3:
                	System.out.println("회원 번호를 입력하세요");
                	String id2 = in.readLine();
                    getProfile(id2);
                    break;
                default:
                    System.exit(0);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void registerUser() throws IOException {
        UserDto userDto = new UserDto();
        System.out.println("=== 회원 정보 등록 ===");
        System.out.print("이름 : ");
        userDto.setName(in.readLine());
        System.out.print("아이디 : ");
        userDto.setId(in.readLine());
        System.out.print("비밀번호 : ");
        userDto.setPw(in.readLine());
        System.out.print("주소 : ");
        userDto.setAddress(in.readLine());
        System.out.print("전화번호 : ");
        userDto.setPhoneNumber(in.readLine());
        bs.registerUser(userDto);
    }

    private void getProfile(String id) {
        UserDto user = bs.getProfile(id);
        System.out.println("********** 회원 정보 **********");
        System.out.println(user.toString());
    }

    private void deleteUser(String id) throws IOException {
        System.out.print("삭제 할 회원 번호 : ");
        int no = Integer.parseInt(in.readLine());
        bs.deleteUser(id);
    }

    public static void main(String[] args) {
        new UserMain();
    }

}