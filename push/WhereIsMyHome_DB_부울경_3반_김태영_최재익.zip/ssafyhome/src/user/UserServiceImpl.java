package user;

import java.util.*;

import user.*;

public class UserServiceImpl implements UserService {
    
    private static UserService instance = new UserServiceImpl();
    
    private UserServiceImpl() {}
    
    public static UserService getUserService() {
        return instance;
    }
    
    @Override
    public void registerUser(UserDto userDto) {
        UserDaoImpl.getUserDao().registerUser(userDto);
    }
    @Override
    public UserDto getProfile(String id) {
        return UserDaoImpl.getUserDao().getProfile(id);
    }
    @Override
    public void deleteUser(String id) {
        UserDaoImpl.getUserDao().deleteUser(id);
    }

}