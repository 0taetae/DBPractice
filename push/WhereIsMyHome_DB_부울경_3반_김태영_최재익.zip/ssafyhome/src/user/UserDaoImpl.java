package user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import util.DBUtil;

public class UserDaoImpl implements UserDao {

    private final String driverName = "com.mysql.cj.jdbc.Driver";
    private final String url = "jdbc:mysql://localhost:3306/ssafyhome?serverTimezone=UTC";
    private final String user = "ssafy";
    private final String pass = "ssafy";

    private static UserDao userDao = new UserDaoImpl();

    private UserDaoImpl() {
        try {
            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static UserDao getUserDao() {
        return userDao;
    }

    @Override
    public void registerUser(UserDto userDto) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBUtil.getInstance().getConnection();
            StringBuilder sql = new StringBuilder();
            sql.append("insert into user(user_id, name, id, pw, address, phonenumber) ");
            sql.append(" values(?,?,?,?,?,?)");

            pstmt = conn.prepareStatement(sql.toString());
            pstmt.setInt(1, userDto.getUser_id());
            pstmt.setString(2, userDto.getName());
            pstmt.setString(3, userDto.getId());
            pstmt.setString(4, userDto.getPw());
            pstmt.setString(5, userDto.getAddress());
            pstmt.setString(6, userDto.getPhoneNumber());

            int cnt = pstmt.executeUpdate();
            System.out.println("User registered successfully. Affected rows: " + cnt);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.getInstance().close(conn, pstmt);
        }
    }

    @Override
    public UserDto getProfile(String id) {
        UserDto userDto = null;
        try (Connection conn = DBUtil.getInstance().getConnection();) {
            StringBuilder sql = new StringBuilder();
            sql.append("select user_id, name, id, pw, address, phonenumber ");
            sql.append("from user ");
            sql.append("where id = ?");

            try (PreparedStatement pstmt = conn.prepareStatement(sql.toString());) {
                pstmt.setString(1, id);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    userDto = new UserDto();
                    userDto.setUser_id(rs.getInt("user_id"));
                    userDto.setName(rs.getString("name"));
                    userDto.setId(rs.getString("id"));
                    userDto.setPw(rs.getString("pw"));
                    userDto.setAddress(rs.getString("address"));
                    userDto.setPhoneNumber(rs.getString("phonenumber"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userDto;
    }

    @Override
    public void deleteUser(String id) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DBUtil.getInstance().getConnection();
            StringBuilder sql = new StringBuilder();
            sql.append("delete from user where user_id = ?");

            pstmt = conn.prepareStatement(sql.toString());
            pstmt.setString(1, id);

            int cnt = pstmt.executeUpdate();
            System.out.println("User deleted successfully. Affected rows: " + cnt);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.getInstance().close(conn, pstmt);
        }
    }
}