package user;


import java.util.List;

public interface UserService {

    void registerUser(UserDto userDto);
    UserDto getProfile(String id);
    void deleteUser(String id); 
    
}