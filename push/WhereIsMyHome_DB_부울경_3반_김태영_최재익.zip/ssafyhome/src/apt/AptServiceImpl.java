package apt;

import java.util.List;
import java.util.Map;
import apt.AptDaoImpl;

public class AptServiceImpl implements AptService{
	
	private static AptService instance = new AptServiceImpl();
	
	private AptServiceImpl() {};
	
	public static AptService getAptService() {
		return instance;
	}

	@Override
	public List<String> getDongCodeList() {
		return AptDaoImpl.getAptDao().getDongCodeList();
	}

	@Override
	public List<String> getAptSeqList(String lawdCd) {
		return AptDaoImpl.getAptDao().getAptSeqList(lawdCd);
	}

	@Override
	public List<Integer> getAptNoList(Map<String, String> map) {
		return AptDaoImpl.getAptDao().getAptNoList(map);
	}

	@Override
	public void registAptInfo(List<AptInfoDto> aptInfoList) {
		AptDaoImpl.getAptDao().registAptInfo(aptInfoList);
	}

	@Override
	public void registAptDeal(List<AptDealDto> aptDeakList) {
		AptDaoImpl.getAptDao().registAptDeal(aptDeakList);
	}
	
}
