package apt;

import apt.AptServiceImpl;
import user.UserService;
import user.UserServiceImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class AptMain {

    private static final String kakaoApiUrl = "https://dapi.kakao.com/v2/local/search/address.xml";
    private static final String kakaoApiKey = "f4f3c0113855c025eb930747c54deba6";

    private static final String dataApiUrl = "https://apis.data.go.kr/1613000/RTMSDataSvcAptTradeDev/getRTMSDataSvcAptTradeDev";
    private static final String dataApiKey = "y5XSeQZQsQ8Iy8DnRRXbj2iZM6AehSGCNWfEfo4%2FTsmdbNnpj0UOouTU0MZdiqsmoz%2BU9Ojp5R9DSuMdT6yKMw%3D%3D";
    private static final String pageNo = "1";
    private static final String numOfRows = "2000";
    private static String LAWD_CD = "11110";
    private static String DEAL_YMD = "201501";
    
    BufferedReader in;
    UserService bs = UserServiceImpl.getUserService();

    public AptMain() {
        in = new BufferedReader(new InputStreamReader(System.in));
        menu();
    }

    private void menu() {
        while (true) {
            System.out.println("---------- 게시판 메뉴 ----------");
            System.out.println("1. 아파트 명으로 찾기 ");
            System.out.println("2. 동 명으로 찾기");
            System.out.println("-------------------------------------");
            System.out.println("0. 프로그램 종료");
            System.out.println("-------------------------------------");
            System.out.print("메뉴 선택 : ");
            try {
                int num = Integer.parseInt(in.readLine());
                switch (num) {
                case 1:
                	findAptNm();
                    break;
                case 2:
                	findDongNm();
                    break;
                default:
                    System.exit(0);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    private void findDongNm() throws IOException{
        Scanner scanner = new Scanner(System.in);
        System.out.print("찾고 싶은 동 이름을 입력하세요: ");
        String inputDongNm = scanner.nextLine();

        Random random = new Random();
        int[] randomTime = { 750, 550, 808, 920, 380, 700, 690, 530, 1000, 450 };

        List<String> dongCodeList = AptServiceImpl.getAptService().getDongCodeList();
//        for(String str : dongCodeList) {
//            System.out.println(str);
//        }
        int cnt = dongCodeList.size();

        for (String lawdCd : dongCodeList) {
            LAWD_CD = lawdCd;
            //System.out.println("현재 작업중 지역 : " + LAWD_CD + ", " + cnt-- + "개 작업 남음!!!");

            boolean[] infoDbExists = new boolean[1000000];

            List<String> aptSeqList = AptServiceImpl.getAptService().getAptSeqList(LAWD_CD);
            for (String seq : aptSeqList)
                infoDbExists[Integer.parseInt(seq.substring(6))] = true;

            List<AptInfoDto> aptInfoList = new ArrayList<>();
            List<AptDealDto> aptDealList = new ArrayList<>();

            StringBuilder dataUrlBuilder = new StringBuilder(dataApiUrl).append("?serviceKey=").append(dataApiKey)
                    .append("&pageNo=").append(URLEncoder.encode(pageNo, "UTF-8")).append("&numOfRows=")
                    .append(URLEncoder.encode(numOfRows, "UTF-8")).append("&LAWD_CD=")
                    .append(URLEncoder.encode(LAWD_CD, "UTF-8")).append("&DEAL_YMD=")
                    .append(URLEncoder.encode(DEAL_YMD, "UTF-8"));

            URL dataUrl = new URL(dataUrlBuilder.toString());
            HttpURLConnection dataConn = (HttpURLConnection) dataUrl.openConnection();
            dataConn.setRequestMethod("GET");
            dataConn.setRequestProperty("Content-type", "application/json");

            BufferedReader dataIn;
            if (dataConn.getResponseCode() >= 200 && dataConn.getResponseCode() <= 300) {
                dataIn = new BufferedReader(new InputStreamReader(dataConn.getInputStream()));
            } else {
                dataIn = new BufferedReader(new InputStreamReader(dataConn.getErrorStream()));
            }
            StringBuilder dataSb = new StringBuilder();
            String dataLine;
            while ((dataLine = dataIn.readLine()) != null) {
                dataSb.append(dataLine);
            }
            dataIn.close();
            dataConn.disconnect();

            try {
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();

                Document dataDocument = builder.parse(new InputSource(new StringReader(dataSb.toString())));
                NodeList dataNodeList = dataDocument.getElementsByTagName("item");
                //System.out.println("apt count : " + dataNodeList.getLength());

                for (int i = 0; i < dataNodeList.getLength(); i++) {
                    AptDealDto aptDealDto = new AptDealDto();

                    Node dataNode = dataNodeList.item(i);
                    if (dataNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element dataElement = (Element) dataNode;

                        // 입력한 동 이름과 일치하는지 확인
                        String umdNm = getValueByTagName(dataElement, "umdNm");
                        if (!umdNm.equals(inputDongNm)) {
                            continue; // 이름이 다르면 처리하지 않고 넘어감
                        }

                        System.out.println("-------------------------------------");
                        System.out.println("동명: " + umdNm);
                        System.out.println("단지명: " + getValueByTagName(dataElement, "aptNm"));
                        System.out.println("층: " + getValueByTagName(dataElement, "floor"));
                        System.out.println("매매년: " + getValueByTagName(dataElement, "dealYear"));
                        System.out.println("거래금액: " + getValueByTagName(dataElement, "dealAmount") + " 만원");

                        aptDealDto.setUmdNm(umdNm);
                        aptDealDto.setAptNm(getValueByTagName(dataElement, "aptNm"));
                        aptDealDto.setFloor(getValueByTagName(dataElement, "floor"));
                        aptDealDto.setDealYear(getValueByTagName(dataElement, "dealYear"));
                        aptDealDto.setDealAmount(getValueByTagName(dataElement, "dealAmount"));

                        aptDealList.add(aptDealDto);
                    }
                }

                //System.out.println("아파트 거래 정보 목록: " + aptDealList.size());

                Thread.sleep(randomTime[random.nextInt(10)]);

                if ((aptDealList.size() != 0))
                    AptServiceImpl.getAptService().registAptDeal(aptDealList);

            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            } catch (SAXException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("수고하셨습니다!!!!");
    }
    
    private void findAptNm() throws IOException{
    	// 사용자로부터 아파트 이름 입력받기
        Scanner scanner = new Scanner(System.in);
        System.out.print("찾고 싶은 아파트 이름을 입력하세요: ");
        String inputAptNm = scanner.nextLine();

        Random random = new Random();
        int[] randomTime = { 750, 550, 808, 920, 380, 700, 690, 530, 1000, 450 };

        List<String> dongCodeList = AptServiceImpl.getAptService().getDongCodeList();
//        for(String str : dongCodeList) {
//            System.out.println(str);
//        }
        int cnt = dongCodeList.size();

        for (String lawdCd : dongCodeList) {
            LAWD_CD = lawdCd;
            //System.out.println("현재 작업중 지역 : " + LAWD_CD + ", " + cnt-- + "개 작업 남음!!!");

            boolean[] infoDbExists = new boolean[1000000];

            List<String> aptSeqList = AptServiceImpl.getAptService().getAptSeqList(LAWD_CD);
            for (String seq : aptSeqList)
                infoDbExists[Integer.parseInt(seq.substring(6))] = true;

            List<AptInfoDto> aptInfoList = new ArrayList<>();
            List<AptDealDto> aptDealList = new ArrayList<>();

            StringBuilder dataUrlBuilder = new StringBuilder(dataApiUrl).append("?serviceKey=").append(dataApiKey)
                    .append("&pageNo=").append(URLEncoder.encode(pageNo, "UTF-8")).append("&numOfRows=")
                    .append(URLEncoder.encode(numOfRows, "UTF-8")).append("&LAWD_CD=")
                    .append(URLEncoder.encode(LAWD_CD, "UTF-8")).append("&DEAL_YMD=")
                    .append(URLEncoder.encode(DEAL_YMD, "UTF-8"));

            URL dataUrl = new URL(dataUrlBuilder.toString());
            HttpURLConnection dataConn = (HttpURLConnection) dataUrl.openConnection();
            dataConn.setRequestMethod("GET");
            dataConn.setRequestProperty("Content-type", "application/json");

            BufferedReader dataIn;
            if (dataConn.getResponseCode() >= 200 && dataConn.getResponseCode() <= 300) {
                dataIn = new BufferedReader(new InputStreamReader(dataConn.getInputStream()));
            } else {
                dataIn = new BufferedReader(new InputStreamReader(dataConn.getErrorStream()));
            }
            StringBuilder dataSb = new StringBuilder();
            String dataLine;
            while ((dataLine = dataIn.readLine()) != null) {
                dataSb.append(dataLine);
            }
            dataIn.close();
            dataConn.disconnect();

            try {
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();

                Document dataDocument = builder.parse(new InputSource(new StringReader(dataSb.toString())));
                NodeList dataNodeList = dataDocument.getElementsByTagName("item");
                //System.out.println("apt count : " + dataNodeList.getLength());

                for (int i = 0; i < dataNodeList.getLength(); i++) {
                    AptDealDto aptDealDto = new AptDealDto();

                    Node dataNode = dataNodeList.item(i);
                    if (dataNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element dataElement = (Element) dataNode;

                        // 입력한 아파트 이름과 일치하는지 확인
                        String aptNm = getValueByTagName(dataElement, "aptNm");
                        if (!aptNm.equals(inputAptNm)) {
                            continue; // 이름이 다르면 처리하지 않고 넘어감
                        }

                        System.out.println("-------------------------------------");
                        System.out.println("단지명: " + aptNm);
                        System.out.println("층: " + getValueByTagName(dataElement, "floor"));
                        System.out.println("매매년: " + getValueByTagName(dataElement, "dealYear"));
                        System.out.println("거래금액: " + getValueByTagName(dataElement, "dealAmount") + " 만원");

                        aptDealDto.setAptNm(aptNm);
                        aptDealDto.setFloor(getValueByTagName(dataElement, "floor"));
                        aptDealDto.setDealYear(getValueByTagName(dataElement, "dealYear"));
                        aptDealDto.setDealAmount(getValueByTagName(dataElement, "dealAmount"));

                        aptDealList.add(aptDealDto);
                    }
                }

                //System.out.println("아파트 거래 정보 목록: " + aptDealList.size());

                Thread.sleep(randomTime[random.nextInt(10)]);

                if ((aptDealList.size() != 0))
                    AptServiceImpl.getAptService().registAptDeal(aptDealList);

            } catch (ParserConfigurationException e) {
                e.printStackTrace();
            } catch (SAXException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("수고하셨습니다!!!!");
    }
    
    public static void main(String[] args) throws IOException {
    	new AptMain();
        
    }

    private static String getValueByTagName(Element element, String tagName) {
        return element.getElementsByTagName(tagName).item(0) != null
                ? element.getElementsByTagName(tagName).item(0).getTextContent()
                : " ";
    }
}
