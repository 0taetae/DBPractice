package com.ssafy.board.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.board.model.BoardDto;
import com.ssafy.util.DBUtil;

public class BoardDaoImpl implements BoardDao {
	
	private static BoardDao boardDao = new BoardDaoImpl();
	
	private BoardDaoImpl() {}

	public static BoardDao getBoardDao() {
		return boardDao;
	}

	@Override
	public void registerArticle(BoardDto boardDto) {
		Connection conn = null;
		PreparedStatement pstmt = null;
//		boardDto의 내용을 board table에 insert 하세요!!!
		try {
			conn = DBUtil.getInstance().getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into board(subject, content, user_id) ");
			sql.append(" values(?,?,?)");
			
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, boardDto.getSubject());
			pstmt.setString(2, boardDto.getContent());
			pstmt.setString(3, boardDto.getUserId());
			
			int cnt = pstmt.executeUpdate();
			System.out.println(cnt+"개 글 등록 완료");
			DBUtil.getInstance().close(conn, pstmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<BoardDto> searchListAll() {
		List<BoardDto> list = new ArrayList<BoardDto>();
//		board table의 모든 글정보를 글번호순으로 정렬하여 list에 담고 return 하세요!!!
// 		=> 문서 기준으로 최신글 정렬함 
		try (Connection conn = DBUtil.getInstance().getConnection();){
			StringBuilder sql = new StringBuilder();
			sql.append("select article_no, subject, content, user_id, ");
			sql.append("register_time ");
			sql.append("from board ");
			sql.append("order by register_time desc "); 
			try(PreparedStatement pstmt = conn.prepareStatement(sql.toString()); ResultSet rs = pstmt.executeQuery();){
				while (rs.next()) {
					BoardDto boardDto = new BoardDto();
					boardDto.setArticleNo(rs.getInt("article_no"));
					boardDto.setSubject(rs.getString("subject"));
					boardDto.setContent(rs.getString("content"));
					boardDto.setUserId(rs.getString("user_id"));
					boardDto.setRegisterTime(rs.getString("register_time"));

					list.add(boardDto);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
//		END
		return list;
	}

	@Override
	public List<BoardDto> searchListBySubject(String subject) {
		List<BoardDto> list = new ArrayList<BoardDto>();
//		board table에서 제목에 subject를 포함하고 있는 글정보를 list에 담고 return 하세요!!!
		try (Connection conn = DBUtil.getInstance().getConnection();){
			StringBuilder sql = new StringBuilder();
			sql.append("select article_no, subject, content, user_id, ");
			sql.append("register_time ");
			sql.append("from board ");
			sql.append("where subject like '%"+subject+"%' "); 
			sql.append("order by register_time desc "); 
			try(PreparedStatement pstmt = conn.prepareStatement(sql.toString()); ResultSet rs = pstmt.executeQuery();){
				while (rs.next()) {
					BoardDto boardDto = new BoardDto();
					boardDto.setArticleNo(rs.getInt("article_no"));
					boardDto.setSubject(rs.getString("subject"));
					boardDto.setContent(rs.getString("content"));
					boardDto.setUserId(rs.getString("user_id"));
					boardDto.setRegisterTime(rs.getString("register_time"));

					list.add(boardDto);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public BoardDto viewArticle(int no) {
		BoardDto boardDto = null;
//		board table에서 글번호가 no인 글 한개를 return 하세요!!!
		try (Connection conn = DBUtil.getInstance().getConnection();){
			StringBuilder sql = new StringBuilder();
			sql.append("select article_no, subject, content, user_id, ");
			sql.append("register_time ");
			sql.append("from board ");
			sql.append("where article_no ="+no+" "); 
			try(PreparedStatement pstmt = conn.prepareStatement(sql.toString()); ResultSet rs = pstmt.executeQuery();){
				if(rs.next()) {
					boardDto = new BoardDto();
					boardDto.setArticleNo(rs.getInt("article_no"));
					boardDto.setSubject(rs.getString("subject"));
					boardDto.setContent(rs.getString("content"));
					boardDto.setUserId(rs.getString("user_id"));
					boardDto.setRegisterTime(rs.getString("register_time"));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return boardDto;
	}

	@Override
	public void modifyArticle(BoardDto boardDto) {
		Connection conn = null;
		PreparedStatement pstmt = null;
//		boardDto의 내용을 이용하여 글번호에 해당하는 글제목과 내용을 수정하세요!!!
		try {
			conn = DBUtil.getInstance().getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("update board set subject=?, content=? ");
			sql.append(" where article_no = ?");
			
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, boardDto.getSubject());
			pstmt.setString(2, boardDto.getContent());
			pstmt.setInt(3, boardDto.getArticleNo());
			
			int cnt = pstmt.executeUpdate();
			System.out.println(cnt+"개 글 수정 완료");
			DBUtil.getInstance().close(conn, pstmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteArticle(int no) {
		Connection conn = null;
		PreparedStatement pstmt = null;
//		board table에서 글번호가 no인 글 정보를 삭제하세요!!!
		try {
			conn = DBUtil.getInstance().getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("delete from board ");
			sql.append(" where article_no=?");
			
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, no);
			
			int cnt = pstmt.executeUpdate();
			System.out.println(cnt+"개 글 삭제 완료");
			DBUtil.getInstance().close(conn, pstmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}






















